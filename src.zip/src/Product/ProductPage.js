import React,{useState,useEffect} from 'react';
import Header from "../Header/Header";
import "./ProductPage.css";
import {connect} from 'react-redux';
import {productApiStart,priceUpdateSuccess,IdUpdate,lengthUpdate} from "../action";
import {Link} from "react-router-dom";

const ProductPage = ({productApiStart,productData,priceUpdateSuccess,count,IdUpdate,id,lengthUpdate,length}) => {

  // const [length,setLength] = useState(0;
  const [error,setError] = useState();
  const [success,setSuccess] = useState(false);
  const [filterText,setfilterText]=useState("")
const[Product,setUpdatedProducts]=useState(productData);

  const CartArr = [];
 
  function handleChange(newValue) {
    setfilterText(newValue);
  }
let selectedProductData={title:"",price:0,image:""};

useEffect(()=>{
  productApiStart();
},[])

useEffect(()=>{

  setUpdatedProducts(productData && productData.length > 0 && productData.filter((value)=>{
   return value.title.toLowerCase().includes(filterText.toLowerCase())
  })
  )
  
  // setUpdatedProducts(updated)
},[filterText])

useEffect(()=>{
    let  timer = setTimeout(() => {
     setError(false);
     setSuccess(false);
    }, 2000);
    return () => clearTimeout(timer);
  },[error,success])

 



  const Products=productData;

    return (
        <>
        <div>
           <Header onChange={handleChange}/>
     <div className="products">
{filterText.length > 0  && Product && Product.map((value,index)=>{
  return(
    <>
               <div className="card">
                 <img src={value.image} className="img"/>
                 <h3 className="title">{value.title}</h3>
                 <p className="ProductPrice">{value.price}</p>
                 <Link to ="/cart">
                 <button className="buttonLeft" onClick={()=>{
                   IdUpdate(value.id)
                  
                   priceUpdateSuccess({...selectedProductData,title:value.title,price:value.price,image:value.image,quantity:1});
                 }}>Buy Now</button>
                 </Link>
                 <button className="buttonRight" onClick={()=>{
                  CartArr.push({title:value.title,price:value.price,image:value.image,quantity:1,id:value.id})
                  IdUpdate(value.id)
                  if(id.includes(value.id)){
                    setError(true)
                    // setShow(false);
                  }else{
                    setSuccess(true);
                  priceUpdateSuccess(CartArr);
                  lengthUpdate(length + 1)
                  }
                      
                      //  console.log(CartArr,"CartArr");

                 }} >Add to Cart</button>
                
               </div>

               {error && <p className="error">Same item Cant be added twice,Please go to Cart to increase Quantity</p>}
               {success && <p className="success">Item Added Succesfully</p>}

    </>
  )
})}

{  filterText==="" && Products.length > 0  && Products.map((value,index)=>{
  return(
    <>
               <div className="card">
                 <img src={value.image} className="img"/>
                 <h3 className="title">{value.title}</h3>
                 <p className="ProductPrice">{value.price}</p>
                 <Link to ="/cart">
                 <button className="buttonLeft" onClick={()=>{
                   IdUpdate(value.id)
                  
                   priceUpdateSuccess({...selectedProductData,title:value.title,price:value.price,image:value.image,quantity:1});
                 }}>Buy Now</button>
                 </Link>
                 <button className="buttonRight" onClick={()=>{
                  CartArr.push({title:value.title,price:value.price,image:value.image,quantity:1,id:value.id})
                  IdUpdate(value.id)
                  if(id.includes(value.id)){
                    setError(true)
                    // setShow(false);
                  }else{
                    setSuccess(true);
                  priceUpdateSuccess(CartArr);
                  lengthUpdate(length + 1)
                  }
                      
                      //  console.log(CartArr,"CartArr");

                 }} >Add to Cart</button>
                
               </div>

               {error && <p className="error">Same item Cant be added twice,Please go to Cart to increase Quantity</p>}
               {success && <p className="success">Item Added Succesfully</p>}

    </>
  )
})}
          

              
            </div>
          
                 
                  
        </div>
        </>
    )
}

const mapStateToProps = state => ({
  productData: state.productData,
  id:state.id,
  length:state.length,
});

const mapDispatchToProps = (dispatch) => ({
  productApiStart : () => dispatch(productApiStart()),
  priceUpdateSuccess:(value) => dispatch(priceUpdateSuccess(value)),
  IdUpdate:(value) => dispatch(IdUpdate(value)),
  lengthUpdate:(value) => dispatch(lengthUpdate(value))
  // IdUpdate
});


export default connect(mapStateToProps,mapDispatchToProps)(ProductPage);
