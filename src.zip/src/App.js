import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router,
  Switch,
  Route,
  Link} from "react-router-dom";
import ProductPage from "./Product/ProductPage";
import CartPage from "./cart/CartPage";



function App() {

  return (
    <div className="App">
     <Router>
       <Switch>
       <Route exact path="/">           
            <ProductPage/>
          </Route>
       <Route path="/cart">           
            <CartPage/>
          </Route>
       </Switch>
     </Router>
    </div>
  );
}

export default App;
