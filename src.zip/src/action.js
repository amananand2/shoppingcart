import actionTypes from "./types";

export const productApiSuccess = (data) => ({
    type: actionTypes.PRODUCT_API_SUCCESS, payload: data 
});

export const productApiStart = () => ({
    type: actionTypes.PRODUCT_API_START,
    
});

export const productApiFailed = () => ({
    type: actionTypes.PRODUCT_API_FAILED
});



export const priceUpdateSuccess = (payload) => ({
    type: actionTypes.PRICE_UPDATE_SUCCESS,
    payload
});

export const IdUpdate = (payload) => ({
    type: actionTypes.ID_UPDATE,
    payload
});

export const lengthUpdate = (payload) => ({
    type: actionTypes.LENGTH_UPDATE,
    payload
});



