import UserActionTypes from "./types";


  const initialState = {
      productData: {},
      loading: false,
      error: false,
      isAuthenticated:false,
      price: [],
      id:[],
      length:0,
    };
    const reducer = (state = initialState, action) => {
      // console.log(action,"action");
      switch (action.type) {
        case UserActionTypes.PRODUCT_API_START:
          return {
            ...state,
            productData: '',
            loading: true,
            isAuthenticated:false,
            error: false,
          };
          case UserActionTypes.PRODUCT_API_SUCCESS:
          return {
            ...state,
            productData: action.payload,
            loading: false,
            isAuthenticated:true,
            error: false,
          };
        case UserActionTypes.PRODUCT_API_FAILED:
          return {
              ...state,
            url: '',
            loading: false,
            error: true,
          };

          case UserActionTypes.PRICE_UPDATE_SUCCESS:
            return {
                ...state,
                 price:state.price.concat(action.payload)
            };

            case UserActionTypes.ID_UPDATE:
              return {
                  ...state,
                   id:state.id.concat(action.payload)
              };

              case UserActionTypes.LENGTH_UPDATE:
                return {
                    ...state,
                     length:action.payload,
                };
        
          
          
        default:
          return state;
      }
    };

    export default reducer;