import { put, takeEvery, all, call } from 'redux-saga/effects';
import actionTypes from "./types";
import {productApiStart,productApiSuccess,productApiFailed} from "./action";


function* helloSaga() {
  console.log('Hello Sagas!')
}

function* watchProductApiStart() {
  yield takeEvery(actionTypes.PRODUCT_API_START, fetchProductApiAsync);
}

function* fetchProductApiAsync() {
  try {
  
    const data = yield call(() => {
      return fetch('https://fakestoreapi.com/products')
              .then(res => res.json())
      });
    yield put(productApiSuccess(data));
  } catch (error) {
    yield put(productApiFailed(error));
  }
}
// notice how we now only export the rootSaga
// single entry point to start all Sagas at once
export default function* rootSaga() {
  yield all([
    helloSaga(),
    watchProductApiStart()
  ])
}