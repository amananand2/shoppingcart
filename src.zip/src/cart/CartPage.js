import React,{useState,useEffect} from 'react'
import Header from "../Header/Header";
import "./CartPage.css";
import {connect} from "react-redux";
import {lengthUpdate} from "../action";


const CartPage = ({productData,lengthUpdate,length}) => {

    const[quantity,setQuantity] = useState(0)



const [cartTotal, setCartTotal] = useState(0);

useEffect(() => {
  total();
}, []);

const total = (id,sign) => {
  let totalVal = 0;
  let quantity=0;
productData && productData.map((value,index)=>{

    totalVal +=value.price;
    quantity  +=value.quantity;
})

  setCartTotal(totalVal);
  setQuantity(quantity);
};

const handleClick=(e,sign)=>{
    if(sign=="add"){
    setCartTotal(prevState=>prevState+e.price);
    e.quantity += 1;
    setQuantity(quantity + 1 );
    lengthUpdate(length + 1)
    }else{
        if(e.quantity==0){
            return ;
        }
    setCartTotal(prevState=>prevState-e.price);
   
    e.quantity -= 1;
    setQuantity(quantity - 1 );
    lengthUpdate(length - 1)
    }

  };





    return (
        <div>
            <Header/>
            <div className="cartDetails">
                <h1>{`Your Cart : ${quantity} items`}</h1>
            </div>
            {productData && productData.map((value,index)=>{
                return(
                    <>
                    <div className="cartDetailsCard">
                <img className="cartDetailsPhoto" src={value.image} alt="productphoto"/>
                <h3 className="cartDetailsHeading">{value.title}</h3>
                <h2>{value.price}</h2>
                <div className="box">
                <button className="decrement" onClick={()=>{
                    handleClick(value,"sub")
                 }}>-</button>
                <p className="items">{value.quantity}</p>
                <button className="increment" onClick={()=>{
                     handleClick(value,"add")
                    }}>+</button>
                </div>
            </div>
                    </>
                )
            })}
            
            
     {length > 0 && <div className="orderSummary">
               <h2 className="summarytitle">Order Summary</h2>
               <h3 className="summaryQuantityTitle">Sub total:</h3>
               <h3 className="summaryQuantity">{`${quantity} units`} </h3>
               <h3 className="summaryPriceTitle">Est total:</h3>
               <h3 className="summaryPrice">{cartTotal.toFixed(2)}</h3>

            </div>
 }
            

        </div>
            
    )
}

const mapStateToProps = state => ({
    productData: state.price,
    length:state.length
  });
  
  const mapDispatchToProps = (dispatch) => ({
  lengthUpdate:(value) => dispatch(lengthUpdate(value))  
  });
  
  
export default connect(mapStateToProps,mapDispatchToProps)(CartPage);
 
