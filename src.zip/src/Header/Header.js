import React,{useState} from 'react';
import "./Header.css";
import {Link} from "react-router-dom";
import {connect} from 'react-redux';
import {productApiStart,priceUpdateSuccess} from "../action";

const Header = ({length,priceUpdateSuccess,onChange}) => {
    const onChang=(e)=>{
        onChange(e.target.value)
    }
    return (
        <div className="header">
            <Link to="/">
            <h1 className="logoLeft">Shop</h1>
            <h1 className="logoRight">IT</h1>
            </Link>
            <input type="search" className="SearchBar" name="gsearch" onChange={(e)=>{onChang(e)}} placeholder="Enter Product Name..."/>
            <input className="submit-btn" type="submit"/>
            <Link to="/cart">
            <h3 className="cart" onClick={()=>{
                // handleChange(true);
            }} >Go to Cart</h3>
            </Link>
            <p className="quantity">{length}</p>
        </div>
    )
}

const mapStateToProps = state => ({
    length: state.length
  });
  
  const mapDispatchToProps = (dispatch) => ({
  priceUpdateSuccess:(value) => dispatch(priceUpdateSuccess(value))
  });
  
  
export default connect(mapStateToProps,mapDispatchToProps)(Header);

